/* memo-role 前端共享工具：请求封装、提示、确认框、格式化。
   纯原生实现，不依赖任何构建工具或外部资源；统一挂在 window.MR 命名空间下。 */
(function (global) {
  'use strict';

  var MR = {};

  // ----------------------------------------------------------------
  // 请求：统一 JSON 收发与错误处理
  // ----------------------------------------------------------------
  /** 读取响应体：优先按 JSON 解析，失败则退回纯文本。 */
  function readBody(res) {
    var ct = res.headers.get('content-type') || '';
    if (ct.indexOf('application/json') !== -1) {
      return res.json().catch(function () { return null; });
    }
    return res.text().then(function (text) {
      if (!text) return null;
      try { return JSON.parse(text); } catch (e) { return { detail: text }; }
    });
  }

  /**
   * 发送请求并返回解析后的数据。
   * 非 2xx 时抛出 Error，message 取服务端 detail，便于直接展示给用户。
   */
  async function request(method, url, body) {
    var opts = { method: method, headers: {} };
    if (body instanceof FormData) {
      opts.body = body; // 交给浏览器自动带 multipart 边界
    } else if (body !== undefined && body !== null) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }

    var res;
    try {
      res = await fetch(url, opts);
    } catch (err) {
      throw new Error('网络请求失败，请确认服务是否在运行');
    }

    var data = await readBody(res);
    if (!res.ok) {
      var detail = data && (data.detail || data.message);
      throw new Error(detail || ('请求失败（HTTP ' + res.status + '）'));
    }
    return data;
  }

  MR.get = function (url) { return request('GET', url); };
  MR.post = function (url, body) { return request('POST', url, body === undefined ? {} : body); };
  MR.put = function (url, body) { return request('PUT', url, body === undefined ? {} : body); };
  MR.del = function (url) { return request('DELETE', url); };
  MR.upload = function (url, formData) { return request('POST', url, formData); };

  /** 拼接查询串：跳过 null / undefined / 空串。 */
  MR.qs = function (params) {
    var parts = [];
    Object.keys(params || {}).forEach(function (key) {
      var value = params[key];
      if (value === null || value === undefined || value === '') return;
      parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    });
    return parts.length ? '?' + parts.join('&') : '';
  };

  // ----------------------------------------------------------------
  // 提示与确认
  // ----------------------------------------------------------------
  /** 轻量瞬时提示；type ∈ info | success | error。 */
  MR.toast = function (message, type) {
    var wrap = document.querySelector('.toast-wrap');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'toast-wrap';
      document.body.appendChild(wrap);
    }
    var el = document.createElement('div');
    el.className = 'toast toast-' + (type || 'info');
    el.textContent = String(message === undefined || message === null ? '' : message);
    wrap.appendChild(el);
    setTimeout(function () { el.remove(); }, 3600);
  };

  /** 通用弹窗：返回 mask 元素（带 .close() 方法）。bodyHtml 由调用方保证安全。 */
  MR.openModal = function (opts) {
    opts = opts || {};
    var mask = document.createElement('div');
    mask.className = 'modal-mask';
    var box = document.createElement('div');
    box.className = 'modal';
    if (opts.width) box.style.maxWidth = opts.width;
    box.innerHTML =
      '<div class="modal-head"><span class="modal-title">' + MR.escape(opts.title || '') + '</span>' +
      '<button class="btn btn-sm btn-ghost" data-close="1" title="关闭">✕</button></div>' +
      '<div class="modal-body">' + (opts.bodyHtml || '') + '</div>' +
      (opts.footHtml ? '<div class="modal-foot">' + opts.footHtml + '</div>' : '');
    mask.appendChild(box);

    mask.close = function () {
      mask.remove();
      if (typeof opts.onClose === 'function') opts.onClose();
    };
    mask.addEventListener('click', function (e) {
      if (e.target === mask) { mask.close(); return; }
      var attr = e.target.getAttribute && e.target.getAttribute('data-close');
      if (attr) mask.close();
    });
    document.body.appendChild(mask);
    return mask;
  };

  /** 基于 promise 的确认框。 */
  MR.confirm = function (message, opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      var mask = MR.openModal({
        title: opts.title || '请确认',
        width: '420px',
        bodyHtml: '<div class="confirm-text"></div>',
        footHtml:
          '<button class="btn btn-ghost" data-act="cancel">取消</button>' +
          '<button class="btn ' + (opts.danger ? 'btn-danger' : 'btn-primary') + '" data-act="ok">确定</button>'
      });
      mask.querySelector('.confirm-text').textContent = String(message || '');
      var done = false;
      mask.addEventListener('click', function (e) {
        var act = e.target.getAttribute && e.target.getAttribute('data-act');
        if (act === 'ok') { done = true; mask.close(); resolve(true); }
        else if (act === 'cancel') { done = true; mask.close(); resolve(false); }
        else if (e.target === mask && !done) { done = true; resolve(false); }
      });
    });
  };

  // ----------------------------------------------------------------
  // 文本与格式化
  // ----------------------------------------------------------------
  /** HTML 转义：所有插入 innerHTML 的服务端数据都必须先过这里。 */
  MR.escape = function (text) {
    if (text === undefined || text === null) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  /** 字节数 → 人类可读。 */
  MR.fmtBytes = function (n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    var units = ['KB', 'MB', 'GB', 'TB'];
    var i = -1;
    do { n = n / 1024; i += 1; } while (n >= 1024 && i < units.length - 1);
    return n.toFixed(n >= 100 ? 0 : 1) + ' ' + units[i];
  };

  /** epoch 秒（可为浮点）→ 本地时间字符串。 */
  MR.fmtTime = function (seconds) {
    var sec = Number(seconds);
    if (!sec && sec !== 0) return '-';
    var d = new Date(sec * 1000);
    if (isNaN(d.getTime()) || sec <= 0) return '-';
    var p = function (x) { return String(x).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) +
      ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  };

  /** 秒数 → “1 天 2 小时 3 分”。 */
  MR.fmtDuration = function (seconds) {
    var s = Math.max(0, Math.floor(Number(seconds) || 0));
    var d = Math.floor(s / 86400); s -= d * 86400;
    var h = Math.floor(s / 3600); s -= h * 3600;
    var m = Math.floor(s / 60);
    var parts = [];
    if (d) parts.push(d + ' 天');
    if (h) parts.push(h + ' 小时');
    parts.push(m + ' 分');
    return parts.join(' ');
  };

  /** 页面顶部的跨页导航链接。 */
  MR.headerNav = function (active) {
    var items = [['/', '聊天'], ['/admin', '管理'], ['/files', '文件']];
    return items.map(function (item) {
      var cls = 'nav-link' + (item[0] === active ? ' active' : '');
      return '<a class="' + cls + '" href="' + item[0] + '">' + MR.escape(item[1]) + '</a>';
    }).join('');
  };

  global.MR = MR;
})(window);